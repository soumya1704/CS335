print "Helloworld"
Apple = 213
Ass_dog = 1266